package dao;

import model.Usuario;
import util.Conexao;
import java.sql.*;

public class UsuarioDAO {

    public boolean validarLogin(String nome, String senha) {
        String sql = "SELECT * FROM Usuarios WHERE Nome = ? AND Senha = ?";

        try (Connection conn = Conexao.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, nome);
            stmt.setString(2, senha);
            ResultSet rs = stmt.executeQuery();
            return rs.next();

        } catch (SQLException e) {
            System.err.println("Erro ao validar login: " + e.getMessage());
            return false;
        }
    }

    public void inserirUsuario(Usuario usuario) {
        String sql = "INSERT INTO Usuarios (Nome, Senha) VALUES (?, ?)";

        try (Connection conn = Conexao.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, usuario.getNome());
            stmt.setString(2, usuario.getSenha());
            stmt.executeUpdate();

            System.out.println("Usuário inserido com sucesso!");

        } catch (SQLException e) {
            System.err.println("Erro ao inserir usuário: " + e.getMessage());
        }
    }
}
