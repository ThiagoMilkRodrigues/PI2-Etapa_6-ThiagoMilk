package dao;

import model.Transacao;
import util.Conexao;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class TransacaoDAO {

    public void inserirTransacao(Transacao t) {
        String sql = "INSERT INTO Transacoes (Usuario, Tipo, Data_registro, Moeda, ValorInvestido, ValorNaCompra, ValorNaVenda, DataCompra, DataVenda) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (Connection conn = Conexao.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql)) {

            stmt.setString(1, t.getUsuario());
            stmt.setString(2, t.getTipo());
            stmt.setString(3, t.getDataRegistro().toString());
            stmt.setString(4, t.getMoeda());
            stmt.setDouble(5, t.getValorInvestido());
            stmt.setDouble(6, t.getValorCompra());
            stmt.setDouble(7, t.getValorVenda());
            stmt.setString(8, t.getDataCompra() != null ? t.getDataCompra().toString() : null);
            stmt.setString(9, t.getDataVenda() != null ? t.getDataVenda().toString() : null);
            stmt.executeUpdate();

            System.out.println("Transação inserida com sucesso!");

        } catch (SQLException e) {
            System.err.println("Erro ao inserir transação: " + e.getMessage());
        }
    }

    public List<Transacao> listarTransacoes() {
        List<Transacao> lista = new ArrayList<>();
        String sql = "SELECT * FROM Transacoes";

        try (Connection conn = Conexao.conectar();
             PreparedStatement stmt = conn.prepareStatement(sql);
             ResultSet rs = stmt.executeQuery()) {

            while (rs.next()) {
                Transacao t = new Transacao(
                        rs.getInt("ID"),
                        rs.getString("Usuario"),
                        rs.getString("Tipo"),
                        rs.getDate("Data_registro").toLocalDate(),
                        rs.getString("Moeda"),
                        rs.getDouble("ValorInvestido"),
                        rs.getDouble("ValorNaCompra"),
                        rs.getDouble("ValorNaVenda"),
                        rs.getDate("DataCompra") != null ? rs.getDate("DataCompra").toLocalDate() : null,
                        rs.getDate("DataVenda") != null ? rs.getDate("DataVenda").toLocalDate() : null
                );
                lista.add(t);
            }

        } catch (SQLException e) {
            System.err.println("Erro ao listar transações: " + e.getMessage());
        }

        return lista;
    }
}
