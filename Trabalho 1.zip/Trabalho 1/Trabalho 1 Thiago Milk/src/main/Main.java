import controller.LoginController;
import controller.TransacaoController;
import model.Transacao;
import java.time.LocalDate;

public class Main {
    public static void main(String[] args) {
        LoginController login = new LoginController();
        TransacaoController transacaoController = new TransacaoController();

        if (login.login("Thiago Milk", "milk1967")) {
            System.out.println("Login realizado com sucesso!");

            Transacao t = new Transacao(
                    0, "thiago", "Compra", LocalDate.now(),
                    "Bitcoin", 2000, 100000, 0, LocalDate.now(), null
            );

            transacaoController.registrar(t);
            transacaoController.listarTodas().forEach(System.out::println);

        } else {
            System.out.println("Falha no login!");
        }
    }
}
