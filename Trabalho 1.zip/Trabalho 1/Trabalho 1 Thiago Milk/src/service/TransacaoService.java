package service;

import dao.TransacaoDAO;
import model.Transacao;
import java.util.List;

public class TransacaoService {
    private TransacaoDAO transacaoDAO = new TransacaoDAO();

    public void adicionar(Transacao t) {
        transacaoDAO.inserirTransacao(t);
    }

    public List<Transacao> listar() {
        return transacaoDAO.listarTransacoes();
    }
}
