package service;

import dao.UsuarioDAO;

public class LoginService {
    private UsuarioDAO usuarioDAO = new UsuarioDAO();

    public boolean autenticar(String nome, String senha) {
        return usuarioDAO.validarLogin(nome, senha);
    }
}
