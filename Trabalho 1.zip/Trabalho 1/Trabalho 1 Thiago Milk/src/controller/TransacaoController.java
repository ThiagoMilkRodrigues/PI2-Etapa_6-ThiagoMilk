package controller;

import model.Transacao;
import service.TransacaoService;
import java.util.List;

public class TransacaoController {
    private TransacaoService service = new TransacaoService();

    public void registrar(Transacao transacao) {
        service.adicionar(transacao);
    }

    public List<Transacao> listarTodas() {
        return service.listar();
    }
}
