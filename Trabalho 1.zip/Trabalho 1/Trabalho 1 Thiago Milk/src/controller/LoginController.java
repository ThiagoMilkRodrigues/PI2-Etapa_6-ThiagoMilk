package controller;

import service.LoginService;

public class LoginController {
    private LoginService loginService = new LoginService();

    public boolean login(String nome, String senha) {
        return loginService.autenticar(nome, senha);
    }
}
