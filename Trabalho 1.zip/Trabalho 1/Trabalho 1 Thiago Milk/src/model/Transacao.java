package model;

import java.time.LocalDate;

public class Transacao {
    private int id;
    private String usuario;
    private String tipo;
    private LocalDate dataRegistro;
    private String moeda;
    private double valorInvestido;
    private double valorCompra;
    private double valorVenda;
    private LocalDate dataCompra;
    private LocalDate dataVenda;

    public Transacao(int id, String usuario, String tipo, LocalDate dataRegistro, String moeda,
                     double valorInvestido, double valorCompra, double valorVenda,
                     LocalDate dataCompra, LocalDate dataVenda) {
        this.id = id;
        this.usuario = usuario;
        this.tipo = tipo;
        this.dataRegistro = dataRegistro;
        this.moeda = moeda;
        this.valorInvestido = valorInvestido;
        this.valorCompra = valorCompra;
        this.valorVenda = valorVenda;
        this.dataCompra = dataCompra;
        this.dataVenda = dataVenda;
    }

    public int getId() { return id; }
    public String getUsuario() { return usuario; }
    public String getTipo() { return tipo; }
    public LocalDate getDataRegistro() { return dataRegistro; }
    public String getMoeda() { return moeda; }
    public double getValorInvestido() { return valorInvestido; }
    public double getValorCompra() { return valorCompra; }
    public double getValorVenda() { return valorVenda; }
    public LocalDate getDataCompra() { return dataCompra; }
    public LocalDate getDataVenda() { return dataVenda; }

    @Override
    public String toString() {
        return "Transacao{" +
                "usuario='" + usuario + '\'' +
                ", tipo='" + tipo + '\'' +
                ", moeda='" + moeda + '\'' +
                ", valorInvestido=" + valorInvestido +
                ", valorCompra=" + valorCompra +
                ", valorVenda=" + valorVenda +
                '}';
    }
}
