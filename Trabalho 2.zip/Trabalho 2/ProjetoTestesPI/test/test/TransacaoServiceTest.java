package test;

import org.junit.Test;
import static org.junit.Assert.*;
import service.TransacaoService;

public class TransacaoServiceTest {

    @Test
    public void testCalcularLucro() {
        TransacaoService service = new TransacaoService();
        float lucro = service.calcularLucro(100, 150);

        assertEquals(50.0f, lucro, 0.01f);
    }
}
