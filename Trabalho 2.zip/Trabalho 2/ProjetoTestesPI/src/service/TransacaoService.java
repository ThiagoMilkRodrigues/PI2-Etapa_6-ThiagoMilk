package service;

public class TransacaoService {

    public float calcularLucro(float valorCompra, float valorVenda) {
        
        float lucro;
        
        lucro = valorVenda - valorCompra;
        
        return lucro;
    }
}
